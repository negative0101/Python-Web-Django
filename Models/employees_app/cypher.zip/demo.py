
import os


def cypher(file_name):
    my_file = os.open(file_name, os.O_RDONLY)
    myData = os.read(my_file, 100000 )
    myStr=myData.decode("UTF-8")
    k = myStr.split('\n')[0]
    text = myStr.split('\n')[1:]
    os.close(my_file)

    #iterrate over the text K times


print(cypher('text.txt'))
